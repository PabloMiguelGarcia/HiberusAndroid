package com.jalper.myfirstapp.helloprefs

object PreferenceKeys {
    const val PREF_KEY = "my_preferences"
    const val PREF_TWO_KEY = "my_second_preferences"
    const val NAME_KEY = "name_key"
    const val PREF_PAGED_VIEWED_KEY = "pref_page_viewed_key"
}